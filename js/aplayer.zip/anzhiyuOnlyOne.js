var anzhiyu_musicPlaying = false;
var anzhiyu_musicFirst = false;